# Southern Cancer Center Nurse Quiz

This package contains:
- `southern_cancer_center_quiz.html`: The interactive quiz for new nurses.
- `README.md`: Instructions for hosting the quiz using GitHub Pages.

## Hosting Instructions (GitHub Pages)

### 1. Create a GitHub Account
Go to [GitHub](https://github.com) and sign up if you don't have an account.

### 2. Create a New Repository
- Click **New Repository**.
- Name it something like `nurse-quiz`.
- Set it to **Public**.
- Click **Create Repository**.

### 3. Upload Files
- In your new repository, click **Add file → Upload files**.
- Upload `southern_cancer_center_quiz.html`.
- Click **Commit changes**.

### 4. Enable GitHub Pages
- Go to **Settings → Pages**.
- Under **Source**, select **Deploy from a branch**.
- Choose:
  - **Branch**: `main`
  - **Folder**: `/root`
- Click **Save**.

### 5. Get Your Shareable Link
After a few minutes, GitHub will provide a link like:
`https://yourusername.github.io/nurse-quiz/`

Share this link with your RNs.

### 6. Test the Quiz
Open the link in a browser and confirm the scoring logic works (90% = PASS).

---
**Passing Criteria:** Nurses must score **90% (18/20)** to pass.
